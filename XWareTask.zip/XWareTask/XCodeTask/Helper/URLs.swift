//
//  URLs.swift
//  XCodeTask
//
//  Created by Sayed Abdo on 6/7/18.
//  Copyright © 2018 Bombo. All rights reserved.
//

import UIKit

enum URLs: String {
    case github = "https://api.github.com/users/apple/repos"
}
