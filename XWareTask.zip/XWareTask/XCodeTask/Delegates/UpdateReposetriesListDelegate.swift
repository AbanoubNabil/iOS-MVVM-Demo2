//
//  UpdatePhotoList.swift
//  MojazTask
//
//  Created by Sayed Abdo on 5/28/18.
//  Copyright © 2018 Bombo. All rights reserved.
//

import Foundation

protocol UpdateReposetriesListDelegate {
    func updateList()
}
